﻿const chai = require('chai');
const expect = chai.expect;
describe('Somas', () => ) {
    it('soma de dois numeros - 2 e3', (done) => {
        const resultado = somarNumeros(2, 3);
        expect(resultado) = somarNumeros(2, 3);
        expect(resultado).be.equal(5);
        done();
      )

    }

};
